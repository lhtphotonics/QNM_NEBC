%% nonclassical_QNM_expan_for_doubleantenna_Esca_PF.m
% This Matlab script calculates the PF of a mesoscale plasmonic
% nanoresonator under the excitation of a point source by using the QNM
% expansion theory to reproduce the scattered field
% Before, the classical QNM must have been calculated, and the background
% field should be known.
% It requires the use of COMSOL LiveLink.
%The script relies on the nonclassical QNM expansion theory published in [].
clear all,
%% %%%%%%%%%%%%%%%%% PARAMETERS TO BE DEFINED BY USER% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% NUMERICAL PARAMETERS
%->some physical constant for computation
c=2.99792458e8;                 % speed of light in vacuum
eps0=8.854187817e-12;           % permittivity of vacuum
eta0=377;                       % wave impedance of light of vacuum
mu0=4*pi*1e-7;                  % permeability of vacuum
%->the electromagnetic characteristic parameters of materials
eps_bg=1;epsilon_AlOx=2.20891555;% the relative permittivity of dielectric
epsiloninf=8.841917311608952;omegap_Au=(2*(pi)*c/((0.163692658125282e-6)))/sqrt(epsiloninf);gamma_Au=(2*(pi)*c/((20.688598658468443e-6)));
epsilon_Au=@(omega)(epsiloninf-epsiloninf*omegap_Au^2./(omega.*(omega-1i*gamma_Au)));% the relative permittivity model of Au
%->the model of Feibelman d parameters
c0=1*(-0.4*1e-9-1i*(-0.6)*1e-9),c1=1*(-1i*(0.5*6.58e-16)*1e-9),zd=-0.1173*1e-9;
dnormal=@(omega)(c0+c1*omega);dparallel=@(omega)(1*(zd*(epsiloninf-1)./(epsilon_Au(omega)-epsilon_AlOx)));

%->the parameters of the point source
p_s=[0,0,1];%z-polarized point source
x_s=0;y_s=0;z_s=0;%the position of point source,which is redifined in the later
%% %%%%%%%%%%%%%%%%%%%%%%%%%%% Read the data of classical QNM from COMSOL model  %%%%%%%%%%%%%%%%%%%%%%%%%
unit=1e6;% the unit of length in COMSOL model,1 for m,1e6 for um;
save_model='Asym_nanowire_dimer_NPoM_antenna_h6_classicalQNM_web';
selection=[82,100,46];%the index of the boundary where N-EBC located
resonator_domain=[21,22];%the index of the scatterer
solnum='all';% the solution number of QNM in COMSOL
dataset='dset1';% the index of dataset in COMSOL
%% Read the data from COMSOL model
model=mphload(save_model);
[D1,D2,L1,L2,h_gap,g_gap,sym_factor]=mphinterp(model,{'D1','D2','L1','L2','h_gap','g_gap','sym_factor'}, 'solnum',1,'coord',[0;0;0],'Complexout','on','unit','m');
d=10e-9;x_s=g_gap/2+L1-d;y_s=0;z_s=h_gap/2;
%-> get the pesudo-energy Fp of QNM (named QN2 in the COMSOL model)  
[Fp,QNM_omega]=mphglobal(model,{'QN2','QNM_omega'},'solnum',solnum,'Complexout','on');
QNM_number=length(QNM_omega);
%-> Read the E field at the location of scatterer
temp=mpheval(model, 'meshvol', 'solnum', 1,'pattern','gauss','selection', resonator_domain);
meshvol=temp.d1;  % mesh volume in m^3
scatterer_cord=temp.p;        % mesh coordinates  
[Ex_s,Ey_s,Ez_s]= mphinterp(model,{'emw.Ex','emw.Ey','emw.Ez'}, 'solnum',solnum,'coord',scatterer_cord,'Complexout','on');
%-> Read Ez at [x_sample;y_sample;z_sample]
x_sample=x_s;y_sample=y_s;z_sample=z_s;
[Ez0]= mphinterp(model,{'emw.Ez'}, 'solnum',solnum,'coord',unit*[x_sample;y_sample;z_sample],'Complexout','on');
%-> Read the field for the calculation of coupling coefficient kappa
antenna_number=2;
mesh_area0=cell(antenna_number);
cord=cell(antenna_number);
for m=1:antenna_number
    temp=mpheval(model, 'meshvol', 'solnum', 1,'pattern','gauss','edim','boundary','selection', selection(m));
    mesh_area0{m}=temp.d1;  % mesh volume in m^3
    cord{m}=temp.p;        % mesh coordinates
    [ez_field_alox,ez_field_au,dx_field,dy_field,ex_field,ey_field,hx_field,hy_filed]=mphinterp(model,{'if(nz==1,down(emw.Ez),up(emw.Ez))',...
        'if(nz==1,up(emw.Ez),down(emw.Ez))','-emw.Ex','-emw.Ey','emw.Ex','emw.Ey','emw.Hx','emw.Hy'},...
        'dataset',dataset,'coord',cord{m},'Complexout','on','edim','boundary','selection',selection(m),'solnum',solnum);
    kapa_field0{m}=cat(3,ez_field_alox,ez_field_au,dx_field,dy_field,ex_field,ey_field,hx_field,hy_filed);
    if m>1
        kapa_field=cat(2,kapa_field,kapa_field0{m});
        mesh_area=cat(2,mesh_area,mesh_area0{m});
    else
        kapa_field=kapa_field0{1};
        mesh_area=mesh_area0{1};
    end
end
temp=mpheval(model, 'meshvol', 'solnum', 1,'pattern','gauss','edim','boundary','selection', selection(antenna_number+1));
mesh_area0{antenna_number+1}=temp.d1;  % mesh volume in m^3
cord{antenna_number+1}=temp.p;        % mesh coordinates

[ez_field_alox,ez_field_au,dx_field,dy_field,ex_field,ey_field,hx_field,hy_filed]=mphinterp(model,{'if(nz==1,up(emw.Ez),down(emw.Ez))',...
    'if(nz==1,down(emw.Ez),up(emw.Ez))','emw.Ex','emw.Ey','emw.Ex','emw.Ey','emw.Hx','emw.Hy'},...
    'dataset',dataset,'coord',cord{antenna_number+1},'Complexout','on','edim','boundary','selection',selection(antenna_number+1),'solnum',solnum);
kapa_field0{antenna_number+1}=cat(3,ez_field_alox,ez_field_au,dx_field,dy_field,ex_field,ey_field,hx_field,hy_filed);

kapa_field=cat(2,kapa_field,kapa_field0{antenna_number+1});mesh_area=cat(2,mesh_area,mesh_area0{antenna_number+1});
%-> normalized the classical QNM with Fp=1;
Esx_norm=bsxfun(@rdivide,Ex_s,sqrt(Fp));
Esy_norm=bsxfun(@rdivide,Ey_s,sqrt(Fp));
Esz_norm=bsxfun(@rdivide,Ez_s,sqrt(Fp));
Ez0_norm=Ez0./sqrt(Fp);
kapa_field_norm=bsxfun(@rdivide,kapa_field,sqrt(Fp));

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Perform the QNM expansion model  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%->  calculate the coupling coefficient
Mdnormal_Alox=sym_factor*(bsxfun(@times,mesh_area,kapa_field_norm(:,:,1))*kapa_field_norm(:,:,1).');
Mdnormal_Au=sym_factor*(bsxfun(@times,mesh_area,kapa_field_norm(:,:,2))*kapa_field_norm(:,:,2).');
Mdparallel=diag(diag(sym_factor*(bsxfun(@times,mesh_area,kapa_field_norm(:,:,5))*kapa_field_norm(:,:,3).'+bsxfun(@times,mesh_area,kapa_field_norm(:,:,6))*kapa_field_norm(:,:,4).')));
Mdnormal_a=diag(diag(eps0*(epsilon_AlOx*Mdnormal_Alox-diag(epsilon_Au(QNM_omega))*Mdnormal_Au)));%M12=M21=0;
Kapa_a=@(omega)-1i*omega*eps0*(epsilon_AlOx-epsilon_Au(omega))*dparallel(omega)*Mdparallel...
        -1i*diag(QNM_omega)*(-dnormal(omega))*Mdnormal_a;%Eq. (2)
%% the solution of the nonclassical QNM under N-EBC
% nonclassical QNM under N-EBC for Model 2A
[X_a,nonclassical.nclQNM_omega_a]=polyeig(-diag(QNM_omega)*(eye(size(Mdnormal_a))-c0*Mdnormal_a),eye(size(Mdnormal_a))-eps0*zd*(1-epsiloninf)*Mdparallel+diag(QNM_omega)*c1*Mdnormal_a);%Eq.(3) in the main text or Eq.(S2.3) in the SM.
%% Preparation for Model 2
A_a=@(omega)(-1i*(diag(omega-QNM_omega))-Kapa_a(omega))
A_adjoint_a=@(omega)inv(A_a(omega))*det(A_a(omega));
small=0.5e-4;
for m=1:1:length(nonclassical.nclQNM_omega_a)
    ncal_omega_p=nonclassical.nclQNM_omega_a(m),
    pAdet_a_omegap(m)=(det(A_a(ncal_omega_p*(1+small)))-det(A_a(ncal_omega_p*(1-small))))/(ncal_omega_p*2*small);
    A_adjoint_a_omegap(1+(m-1)*QNM_number:m*QNM_number,:)=A_adjoint_a(ncal_omega_p);
end
%% Read the data of background field from the COMSOL model and prepare the calculation of excitation coefficient beta
Eb_model='Air_AlOx_Au_PF_Eb_fullwave_web';
model=mphload(Eb_model);
unitb=1e6;% the unit of length in COMSOL model,1 for m,1e6 for um;
outersolnum='all';% outersolnum='all';
dataset='dset1';
[wavelength]= mphinterp(model,{'lam'},'dataset',dataset,'coord',[0;0;0],'Complexout','on','outersolnum',outersolnum,'unit','m');% the wavelength and frequency of excitation source
wavelength=squeeze(wavelength).';
num_lam=length(wavelength);k0=2*pi./wavelength;omegas=2*pi*c./wavelength;

selectionb=[81,78];% the index of the boundary where N-EBC located in the COMSOL model
[xs_b]= mphinterp(model,{'x_s'},'dataset',dataset,'coord',[0;0;0],'Complexout','on','solnum',1,'unit','m');
offset=(xs_b-x_s),
[Ebs_x_re,Ebs_y_re,Ebs_z_re,Ebs_x_im,Ebs_y_im,Ebs_z_im]= mphinterp(model,{'real(emw.Ex)','real(emw.Ey)','real(emw.Ez)','imag(emw.Ex)','imag(emw.Ey)','imag(emw.Ez)'},...
    'dataset',dataset,'outersolnum',outersolnum,'coord',[scatterer_cord(1,:)+offset*unitb;scatterer_cord(2,:);scatterer_cord(3,:)]);
Ebs_x=Ebs_x_re+1i*Ebs_x_im;Ebs_y=Ebs_y_re+1i*Ebs_y_im;Ebs_z=Ebs_z_re+1i*Ebs_z_im;
%-> Read Eb in the nanogap at [x_sample;y_sample;z_sample]
[Ebx0_re,Eby0_re,Ebz0_re,Ebx0_im,Eby0_im,Ebz0_im]= mphinterp(model,{'real(emw.Ex)','real(emw.Ey)','real(emw.Ez)','imag(emw.Ex)','imag(emw.Ey)','imag(emw.Ez)'},...
    'dataset',dataset,'outersolnum',outersolnum,'coord',[x_sample+offset;y_sample;z_sample]*unitb);
Ebx0=Ebx0_re+1i*Ebx0_im;Eby0=Eby0_re+1i*Eby0_im;Ebz0=Ebz0_re+1i*Ebz0_im;
wavelength=mphglobal(model,{'lam'}, 'dataset',dataset, 'outersolnum', outersolnum,'unit','m');
%-> Read Eb at the Au-AlOx boundary 
for m=1:antenna_number
    [ebz_field_alox_re,ebz_field_au_re,ebx_field_re,eby_field_re,ebz_field_alox_im,ebz_field_au_im,ebx_field_im,eby_field_im]= mphinterp(model,{'real(if(nz==1,down(emw.Ez),up(emw.Ez)))','real(if(nz==1,up(emw.Ez),down(emw.Ez)))','real(-emw.Ex)','real(-emw.Ey)',...
        'imag(if(nz==1,down(emw.Ez),up(emw.Ez)))','imag(if(nz==1,up(emw.Ez),down(emw.Ez)))','imag(-emw.Ex)','imag(-emw.Ey)'},...
    'dataset',dataset, 'outersolnum',outersolnum,'coord',[cord{m}(1,:)+offset*unitb;cord{m}(2,:);cord{m}(3,:)],'edim','boundary','selection',selectionb(1));
    ebz_field_alox=ebz_field_alox_re+1i*ebz_field_alox_im;ebz_field_au=ebz_field_au_re+1i*ebz_field_au_im;ebx_field=ebx_field_re+1i*ebx_field_im;eby_field=eby_field_re+1i*eby_field_im;
    Eb_dperp0{m}=cat(4,ebz_field_alox,ebz_field_au,ebx_field,eby_field);
    if m>1
        Ebs_dperp=cat(2,Ebs_dperp,Eb_dperp0{m});
    else
        Ebs_dperp=Eb_dperp0{1};
    end
end
[ebz_field_alox_re,ebz_field_au_re,ebx_field_re,eby_field_re,ebz_field_alox_im,ebz_field_au_im,ebx_field_im,eby_field_im]= mphinterp(model,{'real(if(nz==1,up(emw.Ez),down(emw.Ez)))','real(if(nz==1,down(emw.Ez),up(emw.Ez)))','real(emw.Ex)','real(emw.Ey)',...
        'imag(if(nz==1,up(emw.Ez),down(emw.Ez)))','imag(if(nz==1,down(emw.Ez),up(emw.Ez)))','imag(emw.Ex)','imag(emw.Ey)'},...
    'dataset',dataset, 'outersolnum',outersolnum,'coord',[cord{antenna_number+1}(1,:)+offset*unitb;cord{antenna_number+1}(2,:);cord{antenna_number+1}(3,:)],'edim','boundary','selection',selectionb(2));
ebz_field_alox=ebz_field_alox_re+1i*ebz_field_alox_im;ebz_field_au=ebz_field_au_re+1i*ebz_field_au_im;ebx_field=ebx_field_re+1i*ebx_field_im;eby_field=eby_field_re+1i*eby_field_im;
Eb_dperp0{antenna_number+1}=cat(4,ebz_field_alox,ebz_field_au,ebx_field,eby_field);
Ebs_dperp=cat(2,Ebs_dperp,Eb_dperp0{antenna_number+1});

%% calculate the PF
for m=1:1:num_lam
    omega=omegas(m);
    beta_dperp_a(:,m)=-1i*diag(QNM_omega)*eps0*dnormal(omega)*sym_factor*(epsilon_AlOx*kapa_field_norm(:,:,1)*(mesh_area.*Ebs_dperp(:,:,m,1)).'-diag(epsilon_Au(QNM_omega))*kapa_field_norm(:,:,2)*(mesh_area.*Ebs_dperp(:,:,m,2)).');
    beta_dparallel(:,m)=-1i*omega*eps0*(epsilon_AlOx-epsilon_Au(omega))*dparallel(omega)*sym_factor*(kapa_field_norm(:,:,5)*(mesh_area.*Ebs_dperp(:,:,m,3)).'+kapa_field_norm(:,:,6)*(mesh_area.*Ebs_dperp(:,:,m,4)).'); 
    beta_cl(:,m)=1i*omega.*eps0.*(epsilon_Au(omega)-eps_bg).*sym_factor*sum((bsxfun(@times,Esx_norm,Ebs_x(:,:,m).*meshvol)+...
    bsxfun(@times,Esy_norm,Ebs_y(:,:,m).*meshvol)+bsxfun(@times,Esz_norm,Ebs_z(:,:,m).*meshvol)),2);
    beta_a(:,m)=beta_cl(:,m)+beta_dperp_a(:,m)+beta_dparallel(:,m);
    nonclassical.escaz0_model1(m)=Ez0_norm.'*((-1i*(omega*eye(QNM_number,QNM_number)-diag(QNM_omega))-Kapa_a(omega))\beta_a(:,m)); %Eq. (1), Model 1 with kapa_pq=0 for p not equal to q. 
    nonclassical.escaz0_model2a_p(:,m)=Ez0_norm.'*reshape(A_adjoint_a_omegap*beta_a(:,m),QNM_number,length(nonclassical.nclQNM_omega_a))./((omega-nonclassical.nclQNM_omega_a).'.*pAdet_a_omegap);
    nonclassical.escaz0_model2a(m)=sum(nonclassical.escaz0_model2a_p(:,m),1);%Eq. (4), Model 2A with kapa_pq=0 for p not equal to q.
end
gamma_air=eta0*k0.^2/(12*pi);
nonclassical.PF_model1=-real(nonclassical.escaz0_model1+squeeze(Ebz0).')/2./gamma_air;
nonclassical.PF_model2a=-real(nonclassical.escaz0_model2a+squeeze(Ebz0).')/2./gamma_air;

save(['PF_for_asym_dimer_withoutcrosscoupling','h=',num2str(h_gap*1e9),' L1=',num2str(L1*1e9),' D1=',num2str(D1*1e9),' L2=',num2str(L2*1e9),' D2=',num2str(D2*1e9),'_with_QNM_num=',num2str(QNM_number)],'nonclassical','wavelength');

figure;
plot(1./wavelength,nonclassical.PF_model1,'g-');xlabel('1/\lambda (1/m)');ylabel('PF');grid on;title(['h=',num2str(h_gap),' L1=',num2str(L1),' D1=',num2str(D1),' L2=',num2str(L2),' D2=',num2str(D2)]);
hold on;plot(1./wavelength,nonclassical.PF_model2a,'g-');
legend('Model 1 (\kappa12=\kappa21=0)','Model 2A (\kappa12=\kappa21=0)');


