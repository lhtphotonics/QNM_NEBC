%% nonclassical_QNM_expan_for_singleantenna_PF.m
% This Matlab script calculates the PF of a mesoscale plasmonic 
% nanoresonator under the excitation of a point source by using the QNM expansion theory
% Before, the classical QNM must have been calculated with the COMSOL, such
% as the "Single_nanowire_NPoM_antenna_h6_classicalQNM_web.mph" used here.
% It requires the use of COMSOL LiveLink.
%The script relies on the nonclassical QNM expansion theory proposed in [].
clear all,
%% %%%%%%%%%%%%%%%%% PARAMETERS TO BE DEFINED BY USER% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%->some physical constant for computation
c=2.99792458e8;                 % speed of light in vacuum
eps0=8.854187817e-12;           % permittivity of vacuum
eta0=377;                       % wave impedance of light of vacuum
mu0=4*pi*1e-7;                  % permeability of vacuum
%->the electromagnetic characteristic parameters of materials
eps_bg=1;epsilon_AlOx=2.20891555;% the relative permittivity of dielectric
epsiloninf=8.841917311608952;omegap_Au=(2*(pi)*c/((0.163692658125282e-6)))/sqrt(epsiloninf);gamma_Au=(2*(pi)*c/((20.688598658468443e-6)));
epsilon_Au=@(omega)(epsiloninf-epsiloninf*omegap_Au^2./(omega.*(omega-1i*gamma_Au)));% the relative permittivity model of Au

c0=1*(-0.4*1e-9-1i*(-0.6)*1e-9),c1=1*(-1i*(0.5*6.58e-16)*1e-9),zd=-0.1173*1e-9;
dnormal=@(omega)(c0+c1*omega);dparallel=@(omega)(1*(zd*(epsiloninf-1)./(epsilon_Au(omega)-epsilon_AlOx)));%the model of Feibelman d parameters. 
%->the parameters of the point source
wavelength=(810:5:1010)*1e-9;num_lam=length(wavelength);k0=2*pi./wavelength;omegas=2*pi*c./wavelength;% the wavelength and frequency of excitation source
p_s=[0,0,1];%z-polarized point source
x_s=0;y_s=0;z_s=0;%the position of point source,which is redefined later
%% %%%%%%%%%%%%%%%%%%%%%%%%%%% Read the data of classical QNM from COMSOL model  %%%%%%%%%%%%%%%%%%%%%%%%%
unit=1e6;% the unit of length in the COMSOL model,1 for m,1e6 for um;
save_model='Single_nanowire_NPoM_antenna_h6_classicalQNM_web';
selection=[82,46];%the index of the boundary where N-EBC located
solnum=1;% the index of the QNM
dataset='dset1';% the index of the dataset
fprintf('\nInitialisation overlap integrals ...\n');
%% Read the data from COMSOL model 
model=mphload(save_model); 
[D,L,h_gap,sym_factor]=mphinterp(model,{'D','L','h_gap','sym_factor'}, 'solnum',solnum,'coord',[0;0;0],'Complexout','on','unit','m');
d=10e-9;x_s=L/2-d;y_s=0;z_s=h_gap/2;
%-> get the pesudo-energy Fp of QNM (named QN2 in the COMSOL model)  
[Fp,QNM_omega]=mphglobal(model,{'QN2','QNM_omega'},'solnum',solnum,'Complexout','on'); 
QNM_number=length(QNM_omega);
%-> Read the E field at the location of point source 
[Ex_s,Ey_s,Ez_s]= mphinterp(model,{'emw.Ex','emw.Ey','emw.Ez'}, 'solnum',solnum,'coord',unit*[x_s;y_s;z_s],'Complexout','on');
E_s=[Ex_s,Ey_s,Ez_s];
%-> Read Ez at [x_sample;y_sample;z_sample] 
x_sample=x_s;y_sample=y_s;z_sample=z_s;
[Ez0]= mphinterp(model,{'emw.Ez'}, 'solnum',solnum,'coord',unit*[x_sample;y_sample;z_sample],'Complexout','on');
%-> Read the field for the calculation of coupling coefficient kappa 
temp=mpheval(model, 'meshvol', 'solnum', 1,'pattern','gauss','edim','boundary','selection', selection(1));
mesh_area0{1}=temp.d1;  % mesh volume in m^3
cord{1}=temp.p;        % mesh coordinates  
temp=mpheval(model, 'meshvol', 'solnum', 1,'pattern','gauss','edim','boundary','selection', selection(2));
mesh_area0{2}=temp.d1;  % mesh volume in m^3
cord{2}=temp.p;        % mesh coordinates  
[ez_field_alox,ez_field_au,dx_field,dy_field,ex_field,ey_field,hx_field,hy_filed]=mphinterp(model,{'if(nz==1,down(emw.Ez),up(emw.Ez))',...
    'if(nz==1,up(emw.Ez),down(emw.Ez))','-emw.Ex','-emw.Ey','emw.Ex','emw.Ey','emw.Hx','emw.Hy'},...
    'dataset','dset1','coord',cord{1},'Complexout','on','edim','boundary','selection',selection(1),'solnum',solnum);
kapa_field0{1}=cat(3,ez_field_alox,ez_field_au,dx_field,dy_field,ex_field,ey_field,hx_field,hy_filed);

[ez_field_alox,ez_field_au,dx_field,dy_field,ex_field,ey_field,hx_field,hy_filed]=mphinterp(model,{'if(nz==1,up(emw.Ez),down(emw.Ez))',...
    'if(nz==1,down(emw.Ez),up(emw.Ez))','emw.Ex','emw.Ey','emw.Ex','emw.Ey','emw.Hx','emw.Hy'},...
    'dataset','dset1','coord',cord{2},'Complexout','on','edim','boundary','selection',selection(2),'solnum',solnum);
kapa_field0{2}=cat(3,ez_field_alox,ez_field_au,dx_field,dy_field,ex_field,ey_field,hx_field,hy_filed);

kapa_field=cat(2,kapa_field0{1},kapa_field0{2});mesh_area=cat(2,mesh_area0{1},mesh_area0{2});

%-> normalized the classical QNM with Fp=1;
Es_norm=bsxfun(@rdivide,E_s,sqrt(Fp));
Ez0_norm=Ez0./sqrt(Fp);
kapa_field_norm=bsxfun(@rdivide,kapa_field,sqrt(Fp));
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Perform the QNM expansion model  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%->  calculate the coupling coefficient
Mdnormal_Alox=sym_factor*(bsxfun(@times,mesh_area,kapa_field_norm(:,:,1))*kapa_field_norm(:,:,1).');
Mdnormal_Au=sym_factor*(bsxfun(@times,mesh_area,kapa_field_norm(:,:,2))*kapa_field_norm(:,:,2).');
Mdparallel=sym_factor*(bsxfun(@times,mesh_area,kapa_field_norm(:,:,5))*kapa_field_norm(:,:,3).'+bsxfun(@times,mesh_area,kapa_field_norm(:,:,6))*kapa_field_norm(:,:,4).');
Mdnormal_a=eps0*(epsilon_AlOx*Mdnormal_Alox-diag(epsilon_Au(QNM_omega))*Mdnormal_Au);
Mdnormal_b=@(omega)eps0*(epsilon_AlOx*Mdnormal_Alox-epsilon_Au(omega)*Mdnormal_Au);
%% calculate the nonclassical QNM 
% nonclassical QNM under N-EBC for Model 2A
[X,nonclassical.nclQNM_omega_a]=polyeig(-diag(QNM_omega)*(eye(size(Mdnormal_a))-c0*Mdnormal_a),eye(size(Mdnormal_a))-eps0*zd*(1-epsiloninf)*Mdparallel+diag(QNM_omega)*c1*Mdnormal_a);%Eq.(3) in the main text or Eq.(S2.3) in the SM.
% nonclassical QNM under N-EBC for Model 2B
Mdnormal_nondisp=eps0*(epsilon_AlOx*Mdnormal_Alox-epsiloninf*Mdnormal_Au);
A0=1i*gamma_Au/(2*pi*c)*diag(QNM_omega/(2*pi*c))+c0*eps0*epsiloninf*(omegap_Au/(2*pi*c))^2*Mdnormal_Au;
A1=-1i*gamma_Au/(2*pi*c)*eye(size(Mdparallel))-diag(QNM_omega/(2*pi*c))...
    -(-1i*gamma_Au/(2*pi*c))*zd*eps0*(1-epsiloninf)*Mdparallel+c0*(-1i*gamma_Au/(2*pi*c))*Mdnormal_nondisp+c1*(2*pi*c)*eps0*epsiloninf*(omegap_Au/(2*pi*c))^2*Mdnormal_Au;
A2=eye(size(Mdparallel))-zd*eps0*(1-epsiloninf)*Mdparallel+(c0+(-1i*gamma_Au/(2*pi*c))*c1*(2*pi*c))*Mdnormal_nondisp;
A3=c1*(2*pi*c)*Mdnormal_nondisp;
[X,omega_norm]=polyeig(A0*1e-6,A1,A2*1e6,A3*1e12),
[tmp,mp]=min(abs(omega_norm-QNM_omega));
nonclassical.nclQNM_omega_b=1e6*omega_norm(mp)*2*pi*c;
%% calculate the mode volume
pkapa_a_omegap=-1i*eps0*zd*(1-epsiloninf)*Mdparallel-(-1i)*diag(QNM_omega)*c1*Mdnormal_a;
V_ncl_a=1/(-1i)./(2*eps0*Ez0_norm.^2)*(-1i-pkapa_a_omegap);%the mode volume Eq.(5)
V_cl=1/(-1i)./(2*eps0*Ez0_norm.^2)*(-1i);
Kapa_b=@(omega)-1i*omega*eps0*(epsilon_AlOx-epsilon_Au(omega))*dparallel(omega)*Mdparallel...
    -1i*omega*(-dnormal(omega))*Mdnormal_b(omega);
small=0.5e-4;
pkapa_b_omegap=(Kapa_b(nonclassical.nclQNM_omega_b*(1+small))-Kapa_b(nonclassical.nclQNM_omega_b*(1-small)))/(nonclassical.nclQNM_omega_b*2*small),
V_ncl_b=1/(-1i)/(2*eps0*Ez0_norm.^2)*(-1i-pkapa_b_omegap);
%% calculate the PF
beta=Es_norm*p_s.';% calculate beta 
for m=1:1:num_lam
omega=omegas(m);
Kapa_a(:,:,m)=-1i*omega*eps0*(epsilon_AlOx-epsilon_Au(omega))*dparallel(omega)*Mdparallel...
    -1i*diag(QNM_omega)*(-dnormal(omega))*Mdnormal_a;%Eq.(2)
nonclassical.ez0_model1(m)=Ez0_norm.'*((-1i*(omega*eye(size(Kapa_a(:,:,m)))-diag(QNM_omega))-Kapa_a(:,:,m))\beta); %Eq. (1), Model 1
classical.ez0_model1(m)=Ez0_norm.'*((-1i*(omega*eye(QNM_number,QNM_number)-diag(QNM_omega)))\beta);
end
nonclassical.ez0_model2a=1./(omegas-nonclassical.nclQNM_omega_a)*(Ez0_norm.'*beta)/(-1i-pkapa_a_omegap);%Eq. (4), Model 2A
nonclassical.PF_V_a=3/(4*pi^2)*imag(omegas./(omegas-nonclassical.nclQNM_omega_a)*(1/2/V_ncl_a).*wavelength.^3);%Eq. (5) with Eq. (6), Model 2A 
nonclassical.ez0_model2b=1./(omegas-nonclassical.nclQNM_omega_b)*(Ez0_norm.'*beta)/(-1i-pkapa_b_omegap);%Eq. (7), Model 2B 
nonclassical.PF_V_b=3/(4*pi^2)*imag(omegas./(omegas-nonclassical.nclQNM_omega_b)*(1/2/V_ncl_b).*wavelength.^3);%Eq. (5) with Eq. (8), Model 2B 

gamma_air=eta0*k0.^2/(12*pi);
nonclassical.PF_model1=-real(nonclassical.ez0_model1)/2./gamma_air;
nonclassical.PF_model2a=-real(nonclassical.ez0_model2a)/2./gamma_air;
nonclassical.PF_model2b=-real(nonclassical.ez0_model2b)/2./gamma_air;
classical.PF_model1=-real(classical.ez0_model1)/2./gamma_air;

save(['PF_for_singleantenna_','h=',num2str(h_gap*1e9),' L=',num2str(L*1e9),' D=',num2str(D*1e9),'_with_QNM_num=',num2str(QNM_number)],'nonclassical','classical','wavelength');

figure;
plot(1./wavelength,nonclassical.PF_model1,'b-','color',[0,176/255,240/255]);xlabel('1/\lambda (1/m)');ylabel('PF');grid on;title(['h=',num2str(h_gap),' L=',num2str(L),' D=',num2str(D)]);
hold on;plot(1./wavelength,nonclassical.PF_model2a,'b--','color',[0,176/255,240/255]);
hold on;plot(1./wavelength,nonclassical.PF_V_a,'r-.');
hold on;plot(1./wavelength,nonclassical.PF_model2b,'b--');
hold on;plot(1./wavelength,nonclassical.PF_V_b,'g-.');
hold on;plot(1./wavelength,classical.PF_model1,'r-');
legend('Model 1','Model 2A Eq.(4)','Model 2A Eq.(5)','Model 2B Eq.(7)','Model 2B Eq.(5)','Model 1 under C-EBC');


